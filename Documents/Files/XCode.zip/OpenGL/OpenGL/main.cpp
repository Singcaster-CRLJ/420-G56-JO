#include <GL/glew.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_main.h>
#include <SDL2/SDL_opengl.h>

int main(int argc, const char* argv[]) {
  SDL_Init(SDL_INIT_EVERYTHING);
  
  SDL_Window* sdlWindow = SDL_CreateWindow("OpenGL", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 800, 600, SDL_WINDOW_OPENGL);
  SDL_GLContext sdlGLContext = SDL_GL_CreateContext(sdlWindow);
  
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 4);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 1);

  glewExperimental = true;
  glewInit();
  
  glEnable(GL_DEPTH_TEST);
  
  SDL_Event sdlEvent;
  bool isOpen = true;
  while (isOpen) {
    while (SDL_PollEvent(&sdlEvent))
      isOpen = sdlEvent.type != SDL_QUIT;
    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    SDL_GL_SwapWindow(sdlWindow);
  }
  
  SDL_GL_DeleteContext(sdlGLContext);
  SDL_DestroyWindow(sdlWindow);
  
  SDL_Quit();

  return 0;
}

